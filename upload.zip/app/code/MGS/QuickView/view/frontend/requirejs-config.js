var config = {
    map: {
        '*': {
            magnificPopup: 'MGS_QuickView/js/jquery.magnific-popup.min',
            mgs_quickview: 'MGS_QuickView/js/mgs_quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};

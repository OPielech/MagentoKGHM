var config = {
	"map": {
		"*": {
			"mgs/portfolio": "MGS_Portfolio/js/isotope.pkgd.min",
			"jquery-bridget": "MGS_Portfolio/js/jquery-bridget",
		
		}
	},
	"paths": {            
		"mgs/portfolio": "MGS_Portfolio/js/isotope.pkgd.min",
		"jquery-bridget": "MGS_Portfolio/js/jquery-bridget"
	}
   
};
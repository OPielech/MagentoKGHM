require([
	'jquery'
], function(jQuery){
	(function($) {
		
	})(jQuery);
});
<?php
/*
Custom extension created by Oskar Pielech
which assigns orders limits new orders ond order history view depending on the admin user role.
*/
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'OPModules_AssignOrdersToRoles',
    __DIR__
);

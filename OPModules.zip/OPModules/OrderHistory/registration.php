<?php
/*
Custom extension created by Oskar Pielech
using default Magento classes   
to create custom admin menu with order history grid
*/
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'OPModules_OrderHistory',
    __DIR__
);
